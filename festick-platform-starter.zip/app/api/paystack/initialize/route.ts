import { NextRequest, NextResponse } from 'next/server';
export async function POST(req: NextRequest) {
  if (!process.env.PAYSTACK_SECRET_KEY) return NextResponse.json({error:'Payment provider is not configured.'},{status:500});
  const body = await req.json().catch(()=>null);
  if (!body?.email || !body?.orderId) return NextResponse.json({error:'email and orderId are required.'},{status:400});
  // SECURITY: checkout is intentionally disabled until the server loads a real pending order,
  // calculates the amount from trusted database prices, and verifies ownership/inventory.
  // Never accept the payment amount from browser input.
  return NextResponse.json({error:'Checkout is not enabled yet. Secure order lookup and server-side pricing must be implemented first.'},{status:501});
}
