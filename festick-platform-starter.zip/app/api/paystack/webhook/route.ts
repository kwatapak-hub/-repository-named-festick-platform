import {createHmac,timingSafeEqual} from 'node:crypto';
import {NextRequest,NextResponse} from 'next/server';
export async function POST(req:NextRequest){
 const secret=process.env.PAYSTACK_SECRET_KEY;if(!secret)return NextResponse.json({error:'Webhook not configured'},{status:500});
 const raw=await req.text();const signature=req.headers.get('x-paystack-signature');if(!signature)return NextResponse.json({error:'Missing signature'},{status:401});
 const expected=createHmac('sha512',secret).update(raw).digest('hex');const a=Buffer.from(signature),b=Buffer.from(expected);
 if(a.length!==b.length||!timingSafeEqual(a,b))return NextResponse.json({error:'Invalid signature'},{status:401});
 const event=JSON.parse(raw);
 // TODO: verify charge.success against the matching pending order, amount and ZAR currency;
 // process idempotently; then issue unique tickets and send confirmation emails.
 return NextResponse.json({received:true,event:event.event??'unknown',nextStep:'Implement verified order processing and ticket issuance.'});
}
