import type { Metadata } from 'next'; import './globals.css';
export const metadata: Metadata = { title: 'Festick | Find your next event', description: 'Discover and book events across South Africa.' };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en-ZA"><body>{children}</body></html>; }
